# Order

Endpoints for creating and viewing orders

```ruby
order_api = client.order
```

## Class Name

`OrderApi`

## Methods

* [Place Order](../../doc/controllers/order.md#place-order)
* [Get Order History](../../doc/controllers/order.md#get-order-history)


# Place Order

Creates an order for the specified items and table.

```ruby
def place_order(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`OrderInput`](../../doc/models/order-input.md) | Body, Required | Order payload including items, table number, and customer details. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`OrderResponse`](../../doc/models/order-response.md).

## Example Usage

```ruby
body = OrderInput.new(
  items: [
    OrderItem.new(
      menu_item: '66cfe9b1f23a4a0012ab0001',
      quantity: 2
    ),
    OrderItem.new(
      menu_item: '66cfe9b1f23a4a0012ab0002',
      quantity: 1
    )
  ],
  table_number: 7,
  total_amount: 3297,
  order_type: OrderType::DINEIN,
  customer_details: CustomerDetails.new(
    contact: '+92-300-1234567',
    address: 'Table 7 - Hall A'
  )
)

result = order_api.place_order(body)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "data": {
    "_id": "66cff0aa3a2d4a0012cdbeef",
    "items": [
      {
        "menuItem": "66cfe9b1f23a4a0012ab0001",
        "quantity": 2
      },
      {
        "menuItem": "66cfe9b1f23a4a0012ab0002",
        "quantity": 1
      }
    ],
    "tableNumber": 7,
    "totalAmount": 3297.0,
    "orderType": "dine-in",
    "customerDetails": {
      "contact": "+92-300-1234567",
      "address": "Table 7 - Hall A"
    },
    "status": "pending",
    "createdAt": "2025-08-25T10:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Order History

Returns the authenticated user's recent orders.

```ruby
def get_order_history
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`OrderHistoryResponse`](../../doc/models/order-history-response.md).

## Example Usage

```ruby
result = order_api.get_order_history

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 1,
  "data": [
    {
      "_id": "66cff0aa3a2d4a0012cdbeef",
      "items": [
        {
          "menuItem": "66cfe9b1f23a4a0012ab0001",
          "quantity": 2
        }
      ],
      "tableNumber": 7,
      "totalAmount": 2398.0,
      "orderType": "dine-in",
      "customerDetails": {
        "contact": "+92-300-1234567",
        "address": "Table 7 - Hall A"
      },
      "status": "served",
      "createdAt": "2025-08-20T14:35:00Z"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

