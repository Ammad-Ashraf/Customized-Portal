
# Error Response Exception

Standard error payload.

*This model accepts additional fields of type Object.*

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `TrueClass \| FalseClass` | Required | Always false for errors<br><br>**Default**: `false` |
| `error` | `String` | Required | Human-readable error message |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "success": false,
  "error": "Invalid token",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

