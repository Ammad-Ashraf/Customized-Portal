
# Menu Item

A single menu item available for ordering.

*This model accepts additional fields of type Object.*

## Structure

`MenuItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | Unique identifier of the menu item |
| `name` | `String` | Required | Display name of the item |
| `description` | `String` | Optional | Short description of the item |
| `price` | `Float` | Required | Price in minor currency or standard units, depending on system |
| `category` | `String` | Optional | Category or section |
| `image` | `String` | Optional | Image URL |
| `is_available` | `TrueClass \| FalseClass` | Required | Whether the item is currently available<br><br>**Default**: `true` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "_id": "66cfe9b1f23a4a0012ab0001",
  "name": "Margherita Pizza",
  "description": "Classic pizza with tomato sauce, mozzarella, and basil",
  "price": 1199.0,
  "category": "Pizza",
  "image": "https://cdn.example.com/img/margherita.jpg",
  "isAvailable": true,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

