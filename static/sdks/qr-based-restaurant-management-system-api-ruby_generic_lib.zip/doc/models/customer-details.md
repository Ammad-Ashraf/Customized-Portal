
# Customer Details

Minimal customer contact and delivery info.

*This model accepts additional fields of type Object.*

## Structure

`CustomerDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contact` | `String` | Required | Customer contact number or identifier |
| `address` | `String` | Required | Delivery address or table location note |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "contact": "+92-300-1234567",
  "address": "Table 7 - Hall A",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

