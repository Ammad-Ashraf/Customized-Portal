
# Order Type

How the order will be fulfilled.

## Enumeration

`OrderType`

## Fields

| Name |
|  --- |
| `DINEIN` |
| `TAKEAWAY` |
| `DELIVERY` |

## Example

```
dine-in
```

