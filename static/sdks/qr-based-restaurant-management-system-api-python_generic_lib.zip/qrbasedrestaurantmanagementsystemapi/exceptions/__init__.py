__all__ = [
    'api_exception',
    'error_response_exception',
]
