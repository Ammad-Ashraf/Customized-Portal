
# Error Response Exception

Standard error payload.

*This model accepts additional fields of type Any.*

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `bool` | Required | Always false for errors<br><br>**Default**: `False` |
| `error` | `str` | Required | Human-readable error message |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "success": false,
  "error": "Invalid token",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

