
# Menu Response

Response containing a list of menu items.

*This model accepts additional fields of type Any.*

## Structure

`MenuResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `bool` | Required | Indicates if the request was successful<br><br>**Default**: `True` |
| `count` | `int` | Optional | Number of items returned |
| `data` | [`List[MenuItem]`](../../doc/models/menu-item.md) | Required | Menu items |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "66cfe9b1f23a4a0012ab0001",
      "name": "Margherita Pizza",
      "description": "Classic pizza with tomato sauce, mozzarella, and basil",
      "price": 1199.0,
      "category": "Pizza",
      "image": "https://cdn.example.com/img/margherita.jpg",
      "isAvailable": true,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

