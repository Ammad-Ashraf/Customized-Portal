
# Menu Item

A single menu item available for ordering.

*This model accepts additional fields of type Any.*

## Structure

`MenuItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Required | Unique identifier of the menu item |
| `name` | `str` | Required | Display name of the item |
| `description` | `str` | Optional | Short description of the item |
| `price` | `float` | Required | Price in minor currency or standard units, depending on system |
| `category` | `str` | Optional | Category or section |
| `image` | `str` | Optional | Image URL |
| `is_available` | `bool` | Required | Whether the item is currently available<br><br>**Default**: `True` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "_id": "66cfe9b1f23a4a0012ab0001",
  "name": "Margherita Pizza",
  "description": "Classic pizza with tomato sauce, mozzarella, and basil",
  "price": 1199.0,
  "category": "Pizza",
  "image": "https://cdn.example.com/img/margherita.jpg",
  "isAvailable": true,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

