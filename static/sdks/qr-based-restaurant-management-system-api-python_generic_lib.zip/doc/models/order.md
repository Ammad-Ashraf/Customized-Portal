
# Order

An order placed by a customer.

*This model accepts additional fields of type Any.*

## Structure

`Order`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Required | Order ID |
| `items` | [`List[OrderItem]`](../../doc/models/order-item.md) | Required | List of ordered items |
| `table_number` | `int` | Optional | Table number for dine-in |
| `total_amount` | `float` | Required | Total amount charged |
| `order_type` | [`OrderType`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. |
| `customer_details` | [`CustomerDetails`](../../doc/models/customer-details.md) | Optional | Minimal customer contact and delivery info. |
| `status` | `str` | Required | Current order status<br><br>**Default**: `'pending'` |
| `created_at` | `datetime` | Required | Creation timestamp (ISO 8601) |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example (as JSON)

```json
{
  "_id": "66cff0aa3a2d4a0012cdbeef",
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "status": "pending",
  "createdAt": "08/25/2025 10:00:00",
  "customerDetails": {
    "contact": "contact2",
    "address": "address6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

