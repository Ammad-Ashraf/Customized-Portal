# Menu

Endpoints for browsing menu items

```java
MenuApi menuApi = client.getMenuApi();
```

## Class Name

`MenuApi`


# List Menu Items

Returns the full list of menu items currently available for ordering.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ApiResponse<MenuResponse>> listMenuItemsAsync()
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`MenuResponse`](../../doc/models/menu-response.md).

## Example Usage

```java
menuApi.listMenuItemsAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "66cfe9b1f23a4a0012ab0001",
      "name": "Margherita Pizza",
      "description": "Classic pizza with tomato sauce, mozzarella, and basil",
      "price": 1199.0,
      "category": "Pizza",
      "image": "https://cdn.example.com/img/margherita.jpg",
      "isAvailable": true
    },
    {
      "_id": "66cfe9b1f23a4a0012ab0002",
      "name": "Chicken Biryani",
      "description": "Spiced rice with marinated chicken",
      "price": 899.0,
      "category": "Main",
      "image": "https://cdn.example.com/img/biryani.jpg",
      "isAvailable": true
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

