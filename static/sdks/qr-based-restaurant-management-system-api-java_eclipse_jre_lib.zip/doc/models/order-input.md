
# Order Input

Payload used to create a new order.

*This model accepts additional fields of type Object.*

## Structure

`OrderInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Items` | [`List<OrderItem>`](../../doc/models/order-item.md) | Required | List of items being ordered | List<OrderItem> getItems() | setItems(List<OrderItem> items) |
| `TableNumber` | `int` | Required | Table number for dine-in orders<br><br>**Constraints**: `>= 1` | int getTableNumber() | setTableNumber(int tableNumber) |
| `TotalAmount` | `double` | Required | Total amount for the order<br><br>**Constraints**: `>= 0` | double getTotalAmount() | setTotalAmount(double totalAmount) |
| `OrderType` | [`OrderType`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. | OrderType getOrderType() | setOrderType(OrderType orderType) |
| `CustomerDetails` | [`CustomerDetails`](../../doc/models/customer-details.md) | Required | Minimal customer contact and delivery info. | CustomerDetails getCustomerDetails() | setCustomerDetails(CustomerDetails customerDetails) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "customerDetails": {
    "contact": "+92-300-1234567",
    "address": "Table 7 - Hall A",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

