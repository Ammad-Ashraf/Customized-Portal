
# Error Response Exception

Standard error payload.

*This model accepts additional fields of type Object.*

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `boolean` | Required | Always false for errors<br><br>**Default**: `false` | boolean getSuccess() | setSuccess(boolean success) |
| `Error` | `String` | Required | Human-readable error message | String getError() | setError(String error) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "success": false,
  "error": "Invalid token",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

