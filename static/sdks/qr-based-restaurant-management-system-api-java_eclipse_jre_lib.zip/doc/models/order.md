
# Order

An order placed by a customer.

*This model accepts additional fields of type Object.*

## Structure

`Order`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | Order ID | String getId() | setId(String id) |
| `Items` | [`List<OrderItem>`](../../doc/models/order-item.md) | Required | List of ordered items | List<OrderItem> getItems() | setItems(List<OrderItem> items) |
| `TableNumber` | `Integer` | Optional | Table number for dine-in | Integer getTableNumber() | setTableNumber(Integer tableNumber) |
| `TotalAmount` | `double` | Required | Total amount charged | double getTotalAmount() | setTotalAmount(double totalAmount) |
| `OrderType` | [`OrderType`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. | OrderType getOrderType() | setOrderType(OrderType orderType) |
| `CustomerDetails` | [`CustomerDetails`](../../doc/models/customer-details.md) | Optional | Minimal customer contact and delivery info. | CustomerDetails getCustomerDetails() | setCustomerDetails(CustomerDetails customerDetails) |
| `Status` | `String` | Required | Current order status<br><br>**Default**: `"pending"` | String getStatus() | setStatus(String status) |
| `CreatedAt` | `LocalDateTime` | Required | Creation timestamp (ISO 8601) | LocalDateTime getCreatedAt() | setCreatedAt(LocalDateTime createdAt) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "_id": "66cff0aa3a2d4a0012cdbeef",
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "status": "pending",
  "createdAt": "08/25/2025 10:00:00",
  "customerDetails": {
    "contact": "contact2",
    "address": "address6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

