
# Order Item

An individual line item within an order.

*This model accepts additional fields of type Object.*

## Structure

`OrderItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MenuItem` | `String` | Required | Menu item ID | String getMenuItem() | setMenuItem(String menuItem) |
| `Quantity` | `int` | Required | Quantity ordered<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` | int getQuantity() | setQuantity(int quantity) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "menuItem": "66cfe9b1f23a4a0012ab0001",
  "quantity": 2,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

