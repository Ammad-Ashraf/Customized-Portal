
# Menu Item

A single menu item available for ordering.

*This model accepts additional fields of type Object.*

## Structure

`MenuItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Required | Unique identifier of the menu item | String getId() | setId(String id) |
| `Name` | `String` | Required | Display name of the item | String getName() | setName(String name) |
| `Description` | `String` | Optional | Short description of the item | String getDescription() | setDescription(String description) |
| `Price` | `double` | Required | Price in minor currency or standard units, depending on system | double getPrice() | setPrice(double price) |
| `Category` | `String` | Optional | Category or section | String getCategory() | setCategory(String category) |
| `Image` | `String` | Optional | Image URL | String getImage() | setImage(String image) |
| `IsAvailable` | `boolean` | Required | Whether the item is currently available<br><br>**Default**: `true` | boolean getIsAvailable() | setIsAvailable(boolean isAvailable) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "_id": "66cfe9b1f23a4a0012ab0001",
  "name": "Margherita Pizza",
  "description": "Classic pizza with tomato sauce, mozzarella, and basil",
  "price": 1199.0,
  "category": "Pizza",
  "image": "https://cdn.example.com/img/margherita.jpg",
  "isAvailable": true,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

