
# Menu Response

Response containing a list of menu items.

*This model accepts additional fields of type Object.*

## Structure

`MenuResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `boolean` | Required | Indicates if the request was successful<br><br>**Default**: `true` | boolean getSuccess() | setSuccess(boolean success) |
| `Count` | `Integer` | Optional | Number of items returned | Integer getCount() | setCount(Integer count) |
| `Data` | [`List<MenuItem>`](../../doc/models/menu-item.md) | Required | Menu items | List<MenuItem> getData() | setData(List<MenuItem> data) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "66cfe9b1f23a4a0012ab0001",
      "name": "Margherita Pizza",
      "description": "Classic pizza with tomato sauce, mozzarella, and basil",
      "price": 1199.0,
      "category": "Pizza",
      "image": "https://cdn.example.com/img/margherita.jpg",
      "isAvailable": true,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

