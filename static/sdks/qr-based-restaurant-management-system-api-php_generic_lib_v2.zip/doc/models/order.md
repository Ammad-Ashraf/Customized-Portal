
# Order

An order placed by a customer.

*This model accepts additional fields of type array.*

## Structure

`Order`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Order ID | getId(): string | setId(string id): void |
| `items` | [`OrderItem[]`](../../doc/models/order-item.md) | Required | List of ordered items | getItems(): array | setItems(array items): void |
| `tableNumber` | `?int` | Optional | Table number for dine-in | getTableNumber(): ?int | setTableNumber(?int tableNumber): void |
| `totalAmount` | `float` | Required | Total amount charged | getTotalAmount(): float | setTotalAmount(float totalAmount): void |
| `orderType` | [`string(OrderType)`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. | getOrderType(): string | setOrderType(string orderType): void |
| `customerDetails` | [`?CustomerDetails`](../../doc/models/customer-details.md) | Optional | Minimal customer contact and delivery info. | getCustomerDetails(): ?CustomerDetails | setCustomerDetails(?CustomerDetails customerDetails): void |
| `status` | `string` | Required | Current order status<br><br>**Default**: `'pending'` | getStatus(): string | setStatus(string status): void |
| `createdAt` | `DateTime` | Required | Creation timestamp (ISO 8601) | getCreatedAt(): \DateTime | setCreatedAt(\DateTime createdAt): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "_id": "66cff0aa3a2d4a0012cdbeef",
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "status": "pending",
  "createdAt": "08/25/2025 10:00:00",
  "customerDetails": {
    "contact": "contact2",
    "address": "address6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

