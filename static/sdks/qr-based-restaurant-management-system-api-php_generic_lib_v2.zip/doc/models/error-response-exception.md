
# Error Response Exception

Standard error payload.

*This model accepts additional fields of type array.*

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `bool` | Required | Always false for errors<br><br>**Default**: `false` | getSuccess(): bool | setSuccess(bool success): void |
| `error` | `string` | Required | Human-readable error message | getError(): string | setError(string error): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "success": false,
  "error": "Invalid token",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

