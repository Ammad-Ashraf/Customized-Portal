
# Order Input

Payload used to create a new order.

*This model accepts additional fields of type array.*

## Structure

`OrderInput`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`OrderItem[]`](../../doc/models/order-item.md) | Required | List of items being ordered | getItems(): array | setItems(array items): void |
| `tableNumber` | `int` | Required | Table number for dine-in orders<br><br>**Constraints**: `>= 1` | getTableNumber(): int | setTableNumber(int tableNumber): void |
| `totalAmount` | `float` | Required | Total amount for the order<br><br>**Constraints**: `>= 0` | getTotalAmount(): float | setTotalAmount(float totalAmount): void |
| `orderType` | [`string(OrderType)`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. | getOrderType(): string | setOrderType(string orderType): void |
| `customerDetails` | [`CustomerDetails`](../../doc/models/customer-details.md) | Required | Minimal customer contact and delivery info. | getCustomerDetails(): CustomerDetails | setCustomerDetails(CustomerDetails customerDetails): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "customerDetails": {
    "contact": "+92-300-1234567",
    "address": "Table 7 - Hall A",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

