
# Order History Response

Response containing a list of orders.

*This model accepts additional fields of type array.*

## Structure

`OrderHistoryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `bool` | Required | Indicates if the request was successful<br><br>**Default**: `true` | getSuccess(): bool | setSuccess(bool success): void |
| `count` | `?int` | Optional | Number of orders returned | getCount(): ?int | setCount(?int count): void |
| `data` | [`Order[]`](../../doc/models/order.md) | Required | Orders | getData(): array | setData(array data): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "success": true,
  "count": 1,
  "data": [
    {
      "_id": "66cff0aa3a2d4a0012cdbeef",
      "items": [
        {
          "menuItem": "66cfe9b1f23a4a0012ab0001",
          "quantity": 2,
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "tableNumber": 7,
      "totalAmount": 3297.0,
      "orderType": "dine-in",
      "status": "pending",
      "createdAt": "08/25/2025 10:00:00",
      "customerDetails": {
        "contact": "contact2",
        "address": "address6",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

