
# Menu Item

A single menu item available for ordering.

*This model accepts additional fields of type array.*

## Structure

`MenuItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Unique identifier of the menu item | getId(): string | setId(string id): void |
| `name` | `string` | Required | Display name of the item | getName(): string | setName(string name): void |
| `description` | `?string` | Optional | Short description of the item | getDescription(): ?string | setDescription(?string description): void |
| `price` | `float` | Required | Price in minor currency or standard units, depending on system | getPrice(): float | setPrice(float price): void |
| `category` | `?string` | Optional | Category or section | getCategory(): ?string | setCategory(?string category): void |
| `image` | `?string` | Optional | Image URL | getImage(): ?string | setImage(?string image): void |
| `isAvailable` | `bool` | Required | Whether the item is currently available<br><br>**Default**: `true` | getIsAvailable(): bool | setIsAvailable(bool isAvailable): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "_id": "66cfe9b1f23a4a0012ab0001",
  "name": "Margherita Pizza",
  "description": "Classic pizza with tomato sauce, mozzarella, and basil",
  "price": 1199.0,
  "category": "Pizza",
  "image": "https://cdn.example.com/img/margherita.jpg",
  "isAvailable": true,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

