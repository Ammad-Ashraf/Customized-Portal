
# Menu Response

Response containing a list of menu items.

*This model accepts additional fields of type array.*

## Structure

`MenuResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `bool` | Required | Indicates if the request was successful<br><br>**Default**: `true` | getSuccess(): bool | setSuccess(bool success): void |
| `count` | `?int` | Optional | Number of items returned | getCount(): ?int | setCount(?int count): void |
| `data` | [`MenuItem[]`](../../doc/models/menu-item.md) | Required | Menu items | getData(): array | setData(array data): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "66cfe9b1f23a4a0012ab0001",
      "name": "Margherita Pizza",
      "description": "Classic pizza with tomato sauce, mozzarella, and basil",
      "price": 1199.0,
      "category": "Pizza",
      "image": "https://cdn.example.com/img/margherita.jpg",
      "isAvailable": true,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

