
# Customer Details

Minimal customer contact and delivery info.

*This model accepts additional fields of type array.*

## Structure

`CustomerDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `contact` | `string` | Required | Customer contact number or identifier | getContact(): string | setContact(string contact): void |
| `address` | `string` | Required | Delivery address or table location note | getAddress(): string | setAddress(string address): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "contact": "+92-300-1234567",
  "address": "Table 7 - Hall A",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

