
# Order Item

An individual line item within an order.

*This model accepts additional fields of type array.*

## Structure

`OrderItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `menuItem` | `string` | Required | Menu item ID | getMenuItem(): string | setMenuItem(string menuItem): void |
| `quantity` | `int` | Required | Quantity ordered<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` | getQuantity(): int | setQuantity(int quantity): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

## Example (as JSON)

```json
{
  "menuItem": "66cfe9b1f23a4a0012ab0001",
  "quantity": 2,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

