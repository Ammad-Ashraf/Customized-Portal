# Order

Endpoints for creating and viewing orders

```php
$orderApi = $client->getOrderApi();
```

## Class Name

`OrderApi`

## Methods

* [Place Order](../../doc/controllers/order.md#place-order)
* [Get Order History](../../doc/controllers/order.md#get-order-history)


# Place Order

Creates an order for the specified items and table.

```php
function placeOrder(OrderInput $body): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`OrderInput`](../../doc/models/order-input.md) | Body, Required | Order payload including items, table number, and customer details. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`OrderResponse`](../../doc/models/order-response.md).

## Example Usage

```php
$body = OrderInputBuilder::init(
    [
        OrderItemBuilder::init(
            '66cfe9b1f23a4a0012ab0001',
            2
        )->build(),
        OrderItemBuilder::init(
            '66cfe9b1f23a4a0012ab0002',
            1
        )->build()
    ],
    7,
    3297,
    OrderType::DINEIN,
    CustomerDetailsBuilder::init(
        '+92-300-1234567',
        'Table 7 - Hall A'
    )->build()
)->build();

$apiResponse = $orderApi->placeOrder($body);
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "data": {
    "_id": "66cff0aa3a2d4a0012cdbeef",
    "items": [
      {
        "menuItem": "66cfe9b1f23a4a0012ab0001",
        "quantity": 2
      },
      {
        "menuItem": "66cfe9b1f23a4a0012ab0002",
        "quantity": 1
      }
    ],
    "tableNumber": 7,
    "totalAmount": 3297.0,
    "orderType": "dine-in",
    "customerDetails": {
      "contact": "+92-300-1234567",
      "address": "Table 7 - Hall A"
    },
    "status": "pending",
    "createdAt": "2025-08-25T10:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Order History

Returns the authenticated user's recent orders.

```php
function getOrderHistory(): ApiResponse
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`OrderHistoryResponse`](../../doc/models/order-history-response.md).

## Example Usage

```php
$apiResponse = $orderApi->getOrderHistory();
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 1,
  "data": [
    {
      "_id": "66cff0aa3a2d4a0012cdbeef",
      "items": [
        {
          "menuItem": "66cfe9b1f23a4a0012ab0001",
          "quantity": 2
        }
      ],
      "tableNumber": 7,
      "totalAmount": 2398.0,
      "orderType": "dine-in",
      "customerDetails": {
        "contact": "+92-300-1234567",
        "address": "Table 7 - Hall A"
      },
      "status": "served",
      "createdAt": "2025-08-20T14:35:00Z"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

