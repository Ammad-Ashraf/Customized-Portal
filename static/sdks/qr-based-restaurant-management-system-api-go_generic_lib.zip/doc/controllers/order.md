# Order

Endpoints for creating and viewing orders

```go
orderApi := client.OrderApi()
```

## Class Name

`OrderApi`

## Methods

* [Place Order](../../doc/controllers/order.md#place-order)
* [Get Order History](../../doc/controllers/order.md#get-order-history)


# Place Order

Creates an order for the specified items and table.

```go
PlaceOrder(
    ctx context.Context,
    body models.OrderInput) (
    models.ApiResponse[models.OrderResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.OrderInput`](../../doc/models/order-input.md) | Body, Required | Order payload including items, table number, and customer details. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.OrderResponse](../../doc/models/order-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.OrderInput{
    Items:                 []models.OrderItem{
        models.OrderItem{
            MenuItem:              "66cfe9b1f23a4a0012ab0001",
            Quantity:              2,
        },
        models.OrderItem{
            MenuItem:              "66cfe9b1f23a4a0012ab0002",
            Quantity:              1,
        },
    },
    TableNumber:           7,
    TotalAmount:           float64(3297),
    OrderType:             models.OrderType_Dinein,
    CustomerDetails:       models.CustomerDetails{
        Contact:               "+92-300-1234567",
        Address:               "Table 7 - Hall A",
    },
}

apiResponse, err := orderApi.PlaceOrder(ctx, body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "data": {
    "_id": "66cff0aa3a2d4a0012cdbeef",
    "items": [
      {
        "menuItem": "66cfe9b1f23a4a0012ab0001",
        "quantity": 2
      },
      {
        "menuItem": "66cfe9b1f23a4a0012ab0002",
        "quantity": 1
      }
    ],
    "tableNumber": 7,
    "totalAmount": 3297.0,
    "orderType": "dine-in",
    "customerDetails": {
      "contact": "+92-300-1234567",
      "address": "Table 7 - Hall A"
    },
    "status": "pending",
    "createdAt": "2025-08-25T10:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Get Order History

Returns the authenticated user's recent orders.

```go
GetOrderHistory(
    ctx context.Context) (
    models.ApiResponse[models.OrderHistoryResponse],
    error)
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.OrderHistoryResponse](../../doc/models/order-history-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := orderApi.GetOrderHistory(ctx)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 1,
  "data": [
    {
      "_id": "66cff0aa3a2d4a0012cdbeef",
      "items": [
        {
          "menuItem": "66cfe9b1f23a4a0012ab0001",
          "quantity": 2
        }
      ],
      "tableNumber": 7,
      "totalAmount": 2398.0,
      "orderType": "dine-in",
      "customerDetails": {
        "contact": "+92-300-1234567",
        "address": "Table 7 - Hall A"
      },
      "status": "served",
      "createdAt": "2025-08-20T14:35:00Z"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

