
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in milliseconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`qrBasedRestaurantManagementSystemApiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `qrBasedRestaurantManagementSystemApi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "qrBasedRestaurantManagementSystemApi"
    "net/http"
)

func main() {
    httpConfiguration := qrBasedRestaurantManagementSystemApi.CreateHttpConfiguration(
        qrBasedRestaurantManagementSystemApi.WithTimeout(30),
        qrBasedRestaurantManagementSystemApi.WithTransport(http.DefaultTransport),
        qrBasedRestaurantManagementSystemApi.WithRetryConfiguration(qrBasedRestaurantManagementSystemApi.DefaultRetryConfiguration()),
    )
}
```

