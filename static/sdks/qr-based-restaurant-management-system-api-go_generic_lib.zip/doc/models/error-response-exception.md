
# Error Response Exception

Standard error payload.

*This model accepts additional fields of type interface{}.*

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Success` | `bool` | Required | Always false for errors<br><br>**Default**: `false` |
| `Error` | `string` | Required | Human-readable error message |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "success": false,
  "error": "Invalid token",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

