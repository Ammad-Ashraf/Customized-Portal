
# Order Input

Payload used to create a new order.

*This model accepts additional fields of type interface{}.*

## Structure

`OrderInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Items` | [`[]models.OrderItem`](../../doc/models/order-item.md) | Required | List of items being ordered |
| `TableNumber` | `int` | Required | Table number for dine-in orders<br><br>**Constraints**: `>= 1` |
| `TotalAmount` | `float64` | Required | Total amount for the order<br><br>**Constraints**: `>= 0` |
| `OrderType` | [`models.OrderType`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. |
| `CustomerDetails` | [`models.CustomerDetails`](../../doc/models/customer-details.md) | Required | Minimal customer contact and delivery info. |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "customerDetails": {
    "contact": "+92-300-1234567",
    "address": "Table 7 - Hall A",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

