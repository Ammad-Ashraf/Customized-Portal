
# Order

An order placed by a customer.

*This model accepts additional fields of type interface{}.*

## Structure

`Order`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | Order ID |
| `Items` | [`[]models.OrderItem`](../../doc/models/order-item.md) | Required | List of ordered items |
| `TableNumber` | `*int` | Optional | Table number for dine-in |
| `TotalAmount` | `float64` | Required | Total amount charged |
| `OrderType` | [`models.OrderType`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. |
| `CustomerDetails` | [`*models.CustomerDetails`](../../doc/models/customer-details.md) | Optional | Minimal customer contact and delivery info. |
| `Status` | `string` | Required | Current order status<br><br>**Default**: `"pending"` |
| `CreatedAt` | `time.Time` | Required | Creation timestamp (ISO 8601) |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "_id": "66cff0aa3a2d4a0012cdbeef",
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "status": "pending",
  "createdAt": "08/25/2025 10:00:00",
  "customerDetails": {
    "contact": "contact2",
    "address": "address6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

