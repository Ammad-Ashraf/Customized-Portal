
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
package main

import (
    "qrBasedRestaurantManagementSystemApi"
)

func main() {
    client := qrBasedRestaurantManagementSystemApi.NewClient(
    qrBasedRestaurantManagementSystemApi.CreateConfiguration(
            qrBasedRestaurantManagementSystemApi.WithHttpConfiguration(
                qrBasedRestaurantManagementSystemApi.CreateHttpConfiguration(
                    qrBasedRestaurantManagementSystemApi.WithTimeout(30),
                ),
            ),
            qrBasedRestaurantManagementSystemApi.WithBearerAuthCredentials(
                qrBasedRestaurantManagementSystemApi.NewBearerAuthCredentials("AccessToken"),
            ),
            qrBasedRestaurantManagementSystemApi.WithLoggerConfiguration(
                qrBasedRestaurantManagementSystemApi.WithLevel("info"),
                qrBasedRestaurantManagementSystemApi.WithRequestConfiguration(
                    qrBasedRestaurantManagementSystemApi.WithRequestBody(true),
                ),
                qrBasedRestaurantManagementSystemApi.WithResponseConfiguration(
                    qrBasedRestaurantManagementSystemApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## QR-Based Restaurant Management System API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| MenuApi() | Gets MenuApi |
| OrderApi() | Gets OrderApi |

