
# Getting Started with QR-Based Restaurant Management System API

## Introduction

API for browsing menu items and placing orders in a QR-based restaurant system.

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the qrBasedRestaurantManagementSystemApi library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace qrBasedRestaurantManagementSystemApi => ".\\qr-based-restaurant-management-system-api-go_generic_lib" // local path to the SDK

require qrBasedRestaurantManagementSystemApi v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](doc/auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
package main

import (
    "qrBasedRestaurantManagementSystemApi"
)

func main() {
    client := qrBasedRestaurantManagementSystemApi.NewClient(
    qrBasedRestaurantManagementSystemApi.CreateConfiguration(
            qrBasedRestaurantManagementSystemApi.WithHttpConfiguration(
                qrBasedRestaurantManagementSystemApi.CreateHttpConfiguration(
                    qrBasedRestaurantManagementSystemApi.WithTimeout(30),
                ),
            ),
            qrBasedRestaurantManagementSystemApi.WithBearerAuthCredentials(
                qrBasedRestaurantManagementSystemApi.NewBearerAuthCredentials("AccessToken"),
            ),
            qrBasedRestaurantManagementSystemApi.WithLoggerConfiguration(
                qrBasedRestaurantManagementSystemApi.WithLevel("info"),
                qrBasedRestaurantManagementSystemApi.WithRequestConfiguration(
                    qrBasedRestaurantManagementSystemApi.WithRequestBody(true),
                ),
                qrBasedRestaurantManagementSystemApi.WithResponseConfiguration(
                    qrBasedRestaurantManagementSystemApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Authorization

This API uses the following authentication schemes.

* [`bearerAuth (OAuth 2 Bearer token)`](doc/auth/oauth-2-bearer-token.md)

## List of APIs

* [Menu](doc/controllers/menu.md)
* [Order](doc/controllers/order.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

