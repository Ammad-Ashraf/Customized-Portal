# Order

Endpoints for creating and viewing orders

```ts
const orderApi = new OrderApi(client);
```

## Class Name

`OrderApi`

## Methods

* [Place Order](../../doc/controllers/order.md#place-order)
* [Get Order History](../../doc/controllers/order.md#get-order-history)


# Place Order

Creates an order for the specified items and table.

```ts
async placeOrder(
  body: OrderInput,
  requestOptions?: RequestOptions
): Promise<ApiResponse<OrderResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`OrderInput`](../../doc/models/order-input.md) | Body, Required | Order payload including items, table number, and customer details. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`OrderResponse`](../../doc/models/order-response.md).

## Example Usage

```ts
const body: OrderInput = {
  items: [
    {
      menuItem: '66cfe9b1f23a4a0012ab0001',
      quantity: 2,
    },
    {
      menuItem: '66cfe9b1f23a4a0012ab0002',
      quantity: 1,
    }
  ],
  tableNumber: 7,
  totalAmount: 3297,
  orderType: OrderType.Dinein,
  customerDetails: {
    contact: '+92-300-1234567',
    address: 'Table 7 - Hall A',
  },
};

try {
  const { result, ...httpResponse } = await orderApi.placeOrder(body);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "data": {
    "_id": "66cff0aa3a2d4a0012cdbeef",
    "items": [
      {
        "menuItem": "66cfe9b1f23a4a0012ab0001",
        "quantity": 2
      },
      {
        "menuItem": "66cfe9b1f23a4a0012ab0002",
        "quantity": 1
      }
    ],
    "tableNumber": 7,
    "totalAmount": 3297.0,
    "orderType": "dine-in",
    "customerDetails": {
      "contact": "+92-300-1234567",
      "address": "Table 7 - Hall A"
    },
    "status": "pending",
    "createdAt": "2025-08-25T10:00:00Z"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 401 | Unauthorized | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 500 | Server error | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Get Order History

Returns the authenticated user's recent orders.

```ts
async getOrderHistory(
  requestOptions?: RequestOptions
): Promise<ApiResponse<OrderHistoryResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`OrderHistoryResponse`](../../doc/models/order-history-response.md).

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await orderApi.getOrderHistory();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 1,
  "data": [
    {
      "_id": "66cff0aa3a2d4a0012cdbeef",
      "items": [
        {
          "menuItem": "66cfe9b1f23a4a0012ab0001",
          "quantity": 2
        }
      ],
      "tableNumber": 7,
      "totalAmount": 2398.0,
      "orderType": "dine-in",
      "customerDetails": {
        "contact": "+92-300-1234567",
        "address": "Table 7 - Hall A"
      },
      "status": "served",
      "createdAt": "2025-08-20T14:35:00Z"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`ErrorResponseError`](../../doc/models/error-response-error.md) |
| 500 | Server error | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

