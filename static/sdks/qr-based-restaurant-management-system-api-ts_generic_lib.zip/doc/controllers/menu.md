# Menu

Endpoints for browsing menu items

```ts
const menuApi = new MenuApi(client);
```

## Class Name

`MenuApi`


# List Menu Items

Returns the full list of menu items currently available for ordering.

:information_source: **Note** This endpoint does not require authentication.

```ts
async listMenuItems(
  requestOptions?: RequestOptions
): Promise<ApiResponse<MenuResponse>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`MenuResponse`](../../doc/models/menu-response.md).

## Example Usage

```ts
try {
  const { result, ...httpResponse } = await menuApi.listMenuItems();
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "66cfe9b1f23a4a0012ab0001",
      "name": "Margherita Pizza",
      "description": "Classic pizza with tomato sauce, mozzarella, and basil",
      "price": 1199.0,
      "category": "Pizza",
      "image": "https://cdn.example.com/img/margherita.jpg",
      "isAvailable": true
    },
    {
      "_id": "66cfe9b1f23a4a0012ab0002",
      "name": "Chicken Biryani",
      "description": "Spiced rice with marinated chicken",
      "price": 899.0,
      "category": "Main",
      "image": "https://cdn.example.com/img/biryani.jpg",
      "isAvailable": true
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Server error | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

