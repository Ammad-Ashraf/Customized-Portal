
# Order Response

Response containing a single order.

*This model accepts additional fields of type unknown.*

## Structure

`OrderResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `boolean` | Required | Indicates if the request was successful<br><br>**Default**: `true` |
| `data` | [`Order`](../../doc/models/order.md) | Required | An order placed by a customer. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "success": true,
  "data": {
    "_id": "66cff0aa3a2d4a0012cdbeef",
    "items": [
      {
        "menuItem": "66cfe9b1f23a4a0012ab0001",
        "quantity": 2,
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "tableNumber": 7,
    "totalAmount": 3297.0,
    "orderType": "dine-in",
    "status": "pending",
    "createdAt": "08/25/2025 10:00:00",
    "customerDetails": {
      "contact": "contact2",
      "address": "address6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

