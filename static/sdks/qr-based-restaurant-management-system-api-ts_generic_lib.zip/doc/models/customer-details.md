
# Customer Details

Minimal customer contact and delivery info.

*This model accepts additional fields of type unknown.*

## Structure

`CustomerDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contact` | `string` | Required | Customer contact number or identifier |
| `address` | `string` | Required | Delivery address or table location note |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "contact": "+92-300-1234567",
  "address": "Table 7 - Hall A",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

