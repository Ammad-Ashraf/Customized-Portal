
# Menu Item

A single menu item available for ordering.

*This model accepts additional fields of type unknown.*

## Structure

`MenuItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | Unique identifier of the menu item |
| `name` | `string` | Required | Display name of the item |
| `description` | `string \| undefined` | Optional | Short description of the item |
| `price` | `number` | Required | Price in minor currency or standard units, depending on system |
| `category` | `string \| undefined` | Optional | Category or section |
| `image` | `string \| undefined` | Optional | Image URL |
| `isAvailable` | `boolean` | Required | Whether the item is currently available<br><br>**Default**: `true` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "_id": "66cfe9b1f23a4a0012ab0001",
  "name": "Margherita Pizza",
  "description": "Classic pizza with tomato sauce, mozzarella, and basil",
  "price": 1199.0,
  "category": "Pizza",
  "image": "https://cdn.example.com/img/margherita.jpg",
  "isAvailable": true,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

