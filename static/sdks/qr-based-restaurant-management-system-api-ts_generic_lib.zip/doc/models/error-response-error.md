
# Error Response Error

Standard error payload.

*This model accepts additional fields of type unknown.*

## Structure

`ErrorResponseError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `boolean` | Required | Always false for errors<br><br>**Default**: `false` |
| `error` | `string` | Required | Human-readable error message |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "success": false,
  "error": "Invalid token",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

