
# Order Input

Payload used to create a new order.

*This model accepts additional fields of type unknown.*

## Structure

`OrderInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | [`OrderItem[]`](../../doc/models/order-item.md) | Required | List of items being ordered |
| `tableNumber` | `number` | Required | Table number for dine-in orders<br><br>**Constraints**: `>= 1` |
| `totalAmount` | `number` | Required | Total amount for the order<br><br>**Constraints**: `>= 0` |
| `orderType` | [`OrderType`](../../doc/models/order-type.md) | Required | How the order will be fulfilled. |
| `customerDetails` | [`CustomerDetails`](../../doc/models/customer-details.md) | Required | Minimal customer contact and delivery info. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "items": [
    {
      "menuItem": "66cfe9b1f23a4a0012ab0001",
      "quantity": 2,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "tableNumber": 7,
  "totalAmount": 3297.0,
  "orderType": "dine-in",
  "customerDetails": {
    "contact": "+92-300-1234567",
    "address": "Table 7 - Hall A",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

