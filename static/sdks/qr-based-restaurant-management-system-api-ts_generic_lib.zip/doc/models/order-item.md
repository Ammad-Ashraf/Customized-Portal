
# Order Item

An individual line item within an order.

*This model accepts additional fields of type unknown.*

## Structure

`OrderItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `menuItem` | `string` | Required | Menu item ID |
| `quantity` | `number` | Required | Quantity ordered<br><br>**Default**: `1`<br><br>**Constraints**: `>= 1` |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example (as JSON)

```json
{
  "menuItem": "66cfe9b1f23a4a0012ab0001",
  "quantity": 2,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

