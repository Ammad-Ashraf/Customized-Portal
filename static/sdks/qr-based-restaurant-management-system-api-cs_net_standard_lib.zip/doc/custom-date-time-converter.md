
# CustomDateTimeConverter

Extends from IsoDateTimeConverter to allow a custom DateTime format.

## Constructors

| Name | Description |
|  --- | --- |
| `CustomDateTimeConverter(string format)` | Initializes a new instance of the <see cref="CustomDateTimeConverter"/> class. |

