# Menu

Endpoints for browsing menu items

```csharp
MenuApi menuApi = client.MenuApi;
```

## Class Name

`MenuApi`


# List Menu Items

Returns the full list of menu items currently available for ordering.

:information_source: **Note** This endpoint does not require authentication.

```csharp
ListMenuItemsAsync()
```

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.MenuResponse](../../doc/models/menu-response.md).

## Example Usage

```csharp
try
{
    ApiResponse<MenuResponse> result = await menuApi.ListMenuItemsAsync();
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Example Response *(as JSON)*

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "66cfe9b1f23a4a0012ab0001",
      "name": "Margherita Pizza",
      "description": "Classic pizza with tomato sauce, mozzarella, and basil",
      "price": 1199.0,
      "category": "Pizza",
      "image": "https://cdn.example.com/img/margherita.jpg",
      "isAvailable": true
    },
    {
      "_id": "66cfe9b1f23a4a0012ab0002",
      "name": "Chicken Biryani",
      "description": "Spiced rice with marinated chicken",
      "price": 899.0,
      "category": "Main",
      "image": "https://cdn.example.com/img/biryani.jpg",
      "isAvailable": true
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Server error | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

