
# Order Type

How the order will be fulfilled.

## Enumeration

`OrderType`

## Fields

| Name |
|  --- |
| `Dinein` |
| `Takeaway` |
| `Delivery` |

## Example

```
dine-in
```

