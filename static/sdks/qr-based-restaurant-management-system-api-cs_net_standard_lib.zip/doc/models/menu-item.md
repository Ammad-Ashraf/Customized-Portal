
# Menu Item

A single menu item available for ordering.

*This model accepts additional fields of type object.*

## Structure

`MenuItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | Unique identifier of the menu item |
| `Name` | `string` | Required | Display name of the item |
| `Description` | `string` | Optional | Short description of the item |
| `Price` | `double` | Required | Price in minor currency or standard units, depending on system |
| `Category` | `string` | Optional | Category or section |
| `Image` | `string` | Optional | Image URL |
| `IsAvailable` | `bool` | Required | Whether the item is currently available<br><br>**Default**: `true` |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example (as JSON)

```json
{
  "_id": "66cfe9b1f23a4a0012ab0001",
  "name": "Margherita Pizza",
  "description": "Classic pizza with tomato sauce, mozzarella, and basil",
  "price": 1199.0,
  "category": "Pizza",
  "image": "https://cdn.example.com/img/margherita.jpg",
  "isAvailable": true,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

